package com.example.yogi

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
